import { Routes } from '@angular/router';
import { PaymentListComponent } from './payment-list/payment-list.component';

export const PAYMENT_ROUTES: Routes = [
  { path: '', component: PaymentListComponent }
];
