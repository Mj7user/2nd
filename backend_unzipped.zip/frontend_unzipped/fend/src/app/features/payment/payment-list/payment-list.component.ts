import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DisbursementService } from '../../../core/services/disbursement.service';
import { AuthService } from '../../../core/services/auth.service';
import { Role } from '../../../core/models/role.enum';
import { DisbursementResponse, PaymentResponse, PaymentMethod } from '../../../core/models/application.model';

@Component({
  selector: 'app-payment-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './payment-list.component.html',
  styleUrl: './payment-list.component.css'
})
export class PaymentListComponent implements OnInit {
  private disbursementService = inject(DisbursementService);
  private authService = inject(AuthService);

  readonly PaymentMethod = PaymentMethod;

  disbursements: DisbursementResponse[] = [];
  payments: PaymentResponse[] = [];
  viewDisbursementId: number = 0;
  paymentsLoaded = false;

  newPay = { disbursementId: 0, method: PaymentMethod.BANK };

  get canCreate(): boolean {
    return this.authService.hasRole(Role.WELFARE_OFFICER, Role.PROGRAM_MANAGER, Role.ADMINISTRATOR);
  }

  ngOnInit(): void {
    this.disbursementService.getAllDisbursements().subscribe({
      next: (data: DisbursementResponse[]) => (this.disbursements = data),
      error: () => console.error('Failed to load disbursements')
    });
  }

  createPayment(): void {
    if (this.newPay.disbursementId === 0) return;
    this.disbursementService.createPayment(this.newPay).subscribe({
      next: () => {
        alert('Payment recorded successfully');
        this.viewDisbursementId = this.newPay.disbursementId;
        this.loadPayments();
      },
      error: (err: { error?: string }) => alert(err.error || 'Failed to create payment')
    });
  }

  loadPayments(): void {
    if (!this.viewDisbursementId) return;
    this.disbursementService.getPaymentsByDisbursement(this.viewDisbursementId).subscribe({
      next: (data: PaymentResponse[]) => {
        this.payments = data;
        this.paymentsLoaded = true;
      },
      error: () => {
        this.payments = [];
        this.paymentsLoaded = true;
      }
    });
  }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      PENDING: 'badge-warning',
      SUCCESS: 'badge-success',
      FAILED: 'badge-danger'
    };
    return map[status] || 'badge-neutral';
  }
}
