import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { LoginRequest, LoginResponse, RegisterRequest, RegisterResponse } from '../models/user.model';
import { Role } from '../models/role.enum';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly apiUrl = environment.apiUrl;
  private currentUserSubject = new BehaviorSubject<LoginResponse | null>(this.getStoredUser());
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  register(request: RegisterRequest): Observable<RegisterResponse> {
    return this.http.post<RegisterResponse>(`${this.apiUrl}/auth/register`, request);
  }

  login(request: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/auth/login`, request).pipe(
      tap(response => {
        localStorage.setItem('auth_token', response.token);
        localStorage.setItem('auth_user', JSON.stringify(response));
        this.currentUserSubject.next(response);
        if (response.userId) {
          this.setUserId(response.userId);
        }
      })
    );
  }

  logout(): void {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_user');
    localStorage.removeItem('user_id');
    localStorage.removeItem('citizen_id');
    this.currentUserSubject.next(null);
    this.router.navigate(['/auth/login']);
  }

  getToken(): string | null {
    return localStorage.getItem('auth_token');
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  getCurrentUser(): LoginResponse | null {
    return this.currentUserSubject.value;
  }

  /**
   * Extracts the clean role from the login response.
   *
   * The backend's AuthService returns the Spring Security authority string
   * in the `role` field (e.g. "ROLE_CITIZEN", "ROLE_ADMINISTRATOR").
   * We strip the "ROLE_" prefix so it matches our Role enum values
   * ("CITIZEN", "ADMINISTRATOR", etc.).
   */
  getUserRole(): Role | null {
    const user = this.getCurrentUser();
    if (!user) return null;
    // Backend login response role is "ROLE_CITIZEN", "ROLE_ADMINISTRATOR" etc.
    // Strip "ROLE_" prefix to match our frontend Role enum.
    const rawRole = user.role;
    const cleanRole = rawRole.startsWith('ROLE_') ? rawRole.substring(5) : rawRole;
    return cleanRole as Role;
  }

  hasRole(...roles: Role[]): boolean {
    const userRole = this.getUserRole();
    return userRole ? roles.includes(userRole) : false;
  }

  /**
   * Returns a display-friendly role name.
   * e.g. "WELFARE_OFFICER" → "Welfare Officer"
   */
  getRoleDisplayName(): string {
    const role = this.getUserRole();
    if (!role) return '';
    return role.replace(/_/g, ' ').replace(/\w\S*/g,
      txt => txt.charAt(0).toUpperCase() + txt.substring(1).toLowerCase()
    );
  }

  setUserId(id: number): void {
    console.log('Setting userId:', id);
    localStorage.setItem('user_id', id.toString());

    const user = this.getCurrentUser();
    if (user && user.userId !== id) {
      const updated = { ...user, userId: id };
      localStorage.setItem('auth_user', JSON.stringify(updated));
      this.currentUserSubject.next(updated);
    }
  }

  getUserId(): number | null {
    const id = localStorage.getItem('user_id');
    if (id) {
      return parseInt(id, 10);
    }

    const user = this.getCurrentUser();
    if (user?.userId) {
      this.setUserId(user.userId);
      return user.userId;
    }

    console.log('Getting userId from localStorage: null');
    return null;
  }

  setCitizenId(id: number): void {
    localStorage.setItem('citizen_id', id.toString());
  }

  getCitizenId(): number | null {
    const id = localStorage.getItem('citizen_id');
    return id ? parseInt(id, 10) : null;
  }

  private getStoredUser(): LoginResponse | null {
    const stored = localStorage.getItem('auth_user');
    return stored ? JSON.parse(stored) : null;
  }
}
