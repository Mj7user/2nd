import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { UserService } from '../../../core/services/user.service';
import { CitizenService } from '../../../core/services/citizen.service';
import { Role } from '../../../core/models/role.enum';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private userService = inject(UserService);
  private citizenService = inject(CitizenService);
  private router = inject(Router);

  loginForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  loading = false;
  errorMsg = '';

  isInvalid(field: string): boolean {
    const ctrl = this.loginForm.get(field);
    return !!(ctrl && ctrl.invalid && ctrl.touched);
  }

  onSubmit(): void {
    if (this.loginForm.invalid) { this.loginForm.markAllAsTouched(); return; }
    this.loading = true;
    this.errorMsg = '';

    this.authService.login(this.loginForm.value).subscribe({
      next: (response) => {
        // Save userId if backend returns it directly.
        if ('userId' in response && response.userId) {
          this.authService.setUserId(response.userId);
          console.log('Login response included userId:', response.userId);
        }

        this.resolveUserId(response.email, response.role);
      },
      error: (err) => {
        this.errorMsg = err.error?.message || err.error || 'Invalid credentials. Please try again.';
        this.loading = false;
      }
    });
  }

  private resolveUserId(email: string, role: string): void {
    console.log('Resolving userId for email:', email, 'role:', role);
    this.userService.getAllUsers().subscribe({
      next: (users) => {
        console.log('Users fetched:', users);
        const match = users.find(u => u.email === email);
        if (match) {
          console.log('User matched:', match);
          this.authService.setUserId(match.userId);
          console.log('UserId stored:', match.userId);

          // If CITIZEN, redirect to profile edit page
          const cleanRole = role.replace('ROLE_', '');
          console.log('Clean role:', cleanRole);
          if (cleanRole === Role.CITIZEN) {
            this.citizenService.getCitizenByUserId(match.userId).subscribe({
              next: (citizen) => {
                this.authService.setCitizenId(citizen.citizenId);
                this.router.navigate(['/citizens']);
                this.loading = false;
              },
              error: () => {
                this.router.navigate(['/citizens']);
                this.loading = false;
              }
            });
            return;
          }
        }
        this.router.navigate(['/dashboard']);
        this.loading = false;
      },
      error: () => {
        const cleanRole = role.replace('ROLE_', '');
        if (cleanRole === Role.CITIZEN) {
          this.router.navigate(['/citizens']);
        } else {
          this.router.navigate(['/dashboard']);
        }
        this.loading = false;
      }
    });
  }
}
