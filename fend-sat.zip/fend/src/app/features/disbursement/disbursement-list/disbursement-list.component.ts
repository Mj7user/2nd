import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DisbursementService } from '../../../core/services/disbursement.service';
import { NotificationService } from '../../../core/services/notification.service';
import { CitizenService } from '../../../core/services/citizen.service';
import { AuthService } from '../../../core/services/auth.service';
import { DisbursementResponse, NotificationCategory, ApplicationResponse } from '../../../core/models/application.model';
import { Role } from '../../../core/models/role.enum';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';
import { ApplicationService } from '../../../core/services/application.service';

@Component({
  selector: 'app-disbursement-list',
  standalone: true,
  imports: [CommonModule, LoaderComponent, FormsModule],
  templateUrl: './disbursement-list.component.html',
  styleUrl: './disbursement-list.component.css'
})
export class DisbursementListComponent implements OnInit {
  private disbursementService = inject(DisbursementService);
  private notificationService = inject(NotificationService);
  private citizenService = inject(CitizenService);
  private authService = inject(AuthService);
  private applicationService = inject(ApplicationService);

  disbursements: DisbursementResponse[] = [];
  applications: ApplicationResponse[] = [];
  statusUpdates: Record<number, string> = {};
  loading = true;
  newDisb = { applicationId: 0, citizenId: 0, amount: 0 };

  get canCreate(): boolean {
    return this.authService.hasRole(Role.WELFARE_OFFICER, Role.PROGRAM_MANAGER, Role.ADMINISTRATOR);
  }
  get canUpdate(): boolean {
    return this.authService.hasRole(Role.WELFARE_OFFICER, Role.PROGRAM_MANAGER, Role.ADMINISTRATOR);
  }

  ngOnInit(): void { 
    this.loadDisbursements(); 
    this.loadApplications();
  }

  loadDisbursements(): void {
    this.disbursementService.getAllDisbursements().subscribe({
      next: data => {
        this.disbursements = data;
        data.forEach(d => this.statusUpdates[d.disbursementId] = d.status);
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  loadApplications(): void {
    this.applicationService.getAllApplications().subscribe({
      next: data => {
        // You can filter for approved applications if necessary, but returning all for now.
        this.applications = data;
      },
      error: err => console.error('Failed to load applications', err)
    });
  }

  onApplicationChange(): void {
    const selectedApp = this.applications.find(a => a.applicationId == this.newDisb.applicationId);
    if (selectedApp) {
      this.newDisb.citizenId = selectedApp.citizenId;
    }
  }

  createDisbursement(): void {
    this.disbursementService.createDisbursement(this.newDisb).subscribe({
      next: disbursement => {
        this.citizenService.getCitizenById(disbursement.citizenId).subscribe({
          next: citizen => {
            this.notificationService.createNotification({
              userId: citizen.userId,
              entityId: disbursement.disbursementId,
              message: `A disbursement of ₹${disbursement.amount} has been created for application #${disbursement.applicationId}.`,
              category: NotificationCategory.DISBURSEMENT
            }).subscribe({
              next: () => this.loadAfterDisbursementCreate(),
              error: () => this.loadAfterDisbursementCreate()
            });
          },
          error: () => this.loadAfterDisbursementCreate()
        });
      },
      error: err => alert(err.error || 'Failed to create disbursement')
    });
  }

  private loadAfterDisbursementCreate(): void {
    this.newDisb = { applicationId: 0, citizenId: 0, amount: 0 };
    this.loadDisbursements();
  }

  updateStatus(id: number): void {
    this.disbursementService.updateDisbursementStatus(id, this.statusUpdates[id]).subscribe({
      next: updated => {
        const idx = this.disbursements.findIndex(d => d.disbursementId === id);
        if (idx >= 0) this.disbursements[idx] = updated;
      },
      error: err => alert(err.error || 'Update failed')
    });
  }

  viewPayments(disbursementId: number): void {
    this.disbursementService.getPaymentsByDisbursement(disbursementId).subscribe({
      next: payments => alert(
        payments.length === 0
          ? 'No payments for this disbursement.'
          : payments.map(p => `Payment #${p.paymentId}: ${p.method} — ${p.status}`).join('\n')
      ),
      error: () => alert('Failed to load payments')
    });
  }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      PROCESSED: 'badge-success', PENDING: 'badge-warning',
      FAILED: 'badge-danger', CANCELLED: 'badge-danger'
    };
    return map[status] || 'badge-neutral';
  }
}
