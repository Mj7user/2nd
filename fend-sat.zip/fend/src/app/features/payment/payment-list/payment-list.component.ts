import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApplicationService } from '../../../core/services/application.service';
import { DisbursementService } from '../../../core/services/disbursement.service';
import { CitizenService } from '../../../core/services/citizen.service';
import { NotificationService } from '../../../core/services/notification.service';
import { AuthService } from '../../../core/services/auth.service';
import {
  ApplicationResponse,
  PaymentMethod,
  NotificationCategory
} from '../../../core/models/application.model';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';

@Component({
  selector: 'app-payment-list',
  standalone: true,
  imports: [CommonModule, FormsModule, LoaderComponent],
  templateUrl: './payment-list.component.html',
  styleUrl: './payment-list.component.css'
})
export class PaymentListComponent implements OnInit {
  private applicationService = inject(ApplicationService);
  private disbursementService = inject(DisbursementService);
  private citizenService = inject(CitizenService);
  private notificationService = inject(NotificationService);
  private authService = inject(AuthService);

  readonly PaymentMethod = PaymentMethod;

  /** All approved applications awaiting payment */
  approvedApplications: ApplicationResponse[] = [];

  /** Track selected payment method per application */
  paymentMethods: Record<number, PaymentMethod> = {};

  /** Track disbursement amount per application */
  disbursementAmounts: Record<number, number> = {};

  /** Track which row is currently being processed */
  processingIds = new Set<number>();

  /** Track which row just completed successfully */
  completedIds = new Set<number>();

  /** Application ID awaiting confirmation */
  confirmAppId: number | null = null;

  loading = true;
  successMessage = '';
  errorMessage = '';

  /** Count of apps processed in this session */
  processedCount = 0;

  ngOnInit(): void {
    this.loadApprovedApplications();
  }

  loadApprovedApplications(): void {
    this.loading = true;
    this.applicationService.getAllApplications().subscribe({
      next: (apps) => {
        this.approvedApplications = apps.filter(a => a.status === 'APPROVED');
        // Initialize defaults for each app
        this.approvedApplications.forEach(app => {
          if (!this.paymentMethods[app.applicationId]) {
            this.paymentMethods[app.applicationId] = PaymentMethod.BANK;
          }
          if (!this.disbursementAmounts[app.applicationId]) {
            this.disbursementAmounts[app.applicationId] = 0;
          }
        });
        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to load applications. Please try again.';
        this.loading = false;
      }
    });
  }

  /** Show confirmation overlay for a specific application */
  confirmProcess(appId: number): void {
    if (this.disbursementAmounts[appId] <= 0) {
      this.errorMessage = 'Please enter a valid disbursement amount.';
      this.clearMessageAfterDelay();
      return;
    }
    this.confirmAppId = appId;
  }

  /** Cancel the confirmation */
  cancelConfirm(): void {
    this.confirmAppId = null;
  }

  /**
   * Full payment processing pipeline:
   * 1. Create disbursement record
   * 2. Create payment record with chosen method
   * 3. Update application status to DISBURSED
   * 4. Send notification to the citizen
   * 5. Refresh the list
   */
  processPayment(appId: number): void {
    this.confirmAppId = null;
    this.successMessage = '';
    this.errorMessage = '';

    const app = this.approvedApplications.find(a => a.applicationId === appId);
    if (!app) return;

    const method = this.paymentMethods[appId];
    const amount = this.disbursementAmounts[appId];

    this.processingIds.add(appId);

    // Step 1: Create disbursement
    this.disbursementService.createDisbursement({
      applicationId: app.applicationId,
      citizenId: app.citizenId,
      amount: amount
    }).subscribe({
      next: (disbursement) => {
        // Step 2: Create payment
        this.disbursementService.createPayment({
          disbursementId: disbursement.disbursementId,
          method: method
        }).subscribe({
          next: () => {
            // Step 3: Update application status to DISBURSED
            this.applicationService.updateApplicationStatus(appId, 'DISBURSED').subscribe({
              next: () => {
                // Step 4: Send notification to citizen
                this.sendCitizenNotification(app, method, amount);
              },
              error: (err) => {
                // Disbursement + payment created but status update failed
                this.handleError(appId, 'Payment recorded but failed to update application status. Please update manually.');
              }
            });
          },
          error: () => {
            this.handleError(appId, 'Disbursement created but payment recording failed. Please try again.');
          }
        });
      },
      error: (err) => {
        this.handleError(appId, err.error || 'Failed to create disbursement. Please try again.');
      }
    });
  }

  /**
   * Look up the citizen's userId and send a notification about the payment.
   */
  private sendCitizenNotification(app: ApplicationResponse, method: PaymentMethod, amount: number): void {
    this.citizenService.getCitizenById(app.citizenId).subscribe({
      next: (citizen) => {
        const methodLabel = this.getMethodLabel(method);
        this.notificationService.createNotification({
          userId: citizen.userId,
          entityId: app.applicationId,
          message: `Your application #${app.applicationId} has been approved and a payment of ₹${amount.toLocaleString('en-IN')} has been disbursed via ${methodLabel}. Status: DISBURSED.`,
          category: NotificationCategory.PAYMENT
        }).subscribe({
          next: () => this.handleSuccess(app.applicationId),
          error: () => {
            // Payment went through, notification failed — still a success
            this.handleSuccess(app.applicationId, true);
          }
        });
      },
      error: () => {
        // Payment went through, citizen lookup failed — still a success
        this.handleSuccess(app.applicationId, true);
      }
    });
  }

  private handleSuccess(appId: number, notifFailed = false): void {
    this.processingIds.delete(appId);
    this.completedIds.add(appId);
    this.processedCount++;

    if (notifFailed) {
      this.successMessage = `Application #${appId} has been disbursed successfully. (Notification could not be sent.)`;
    } else {
      this.successMessage = `Application #${appId} has been disbursed successfully. Citizen has been notified.`;
    }

    this.notificationService.triggerRefresh();
    this.clearMessageAfterDelay();

    // Remove from list after a brief delay so the user can see the success state
    setTimeout(() => {
      this.approvedApplications = this.approvedApplications.filter(a => a.applicationId !== appId);
      this.completedIds.delete(appId);
    }, 2000);
  }

  private handleError(appId: number, message: string): void {
    this.processingIds.delete(appId);
    this.errorMessage = message;
    this.clearMessageAfterDelay();
  }

  private clearMessageAfterDelay(): void {
    setTimeout(() => {
      this.successMessage = '';
      this.errorMessage = '';
    }, 6000);
  }

  getMethodLabel(method: PaymentMethod): string {
    const labels: Record<string, string> = {
      BANK: 'Bank Transfer',
      WALLET: 'Digital Wallet',
      CASH: 'Cash'
    };
    return labels[method] || method;
  }

  isProcessing(appId: number): boolean {
    return this.processingIds.has(appId);
  }

  isCompleted(appId: number): boolean {
    return this.completedIds.has(appId);
  }

  dismissSuccess(): void {
    this.successMessage = '';
  }

  dismissError(): void {
    this.errorMessage = '';
  }
}
