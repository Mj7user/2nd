import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ApplicationService } from '../../../core/services/application.service';
import { AuthService } from '../../../core/services/auth.service';
import { ApplicationResponse } from '../../../core/models/application.model';
import { Role } from '../../../core/models/role.enum';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-application-status',
  standalone: true,
  imports: [CommonModule, LoaderComponent, FormsModule],
  templateUrl: './application-status.component.html',
  styleUrl: './application-status.component.css'
})
export class ApplicationStatusComponent implements OnInit {
  private applicationService = inject(ApplicationService);
  private authService = inject(AuthService);
  private router = inject(Router);

  applications: ApplicationResponse[] = [];
  statusUpdates: Record<number, string> = {};
  loading = true;

  get isCitizen(): boolean { return this.authService.hasRole(Role.CITIZEN); }
  get canCreate(): boolean { return this.authService.hasRole(Role.CITIZEN, Role.WELFARE_OFFICER, Role.ADMINISTRATOR); }
  get canUpdateStatus(): boolean { return this.authService.hasRole(Role.WELFARE_OFFICER, Role.ADMINISTRATOR); }

  ngOnInit(): void { this.loadApplications(); }

  loadApplications(): void {
    if (this.isCitizen) {
      const citizenId = this.authService.getCitizenId();
      if (citizenId) {
        this.applicationService.getApplicationsByCitizen(citizenId).subscribe({
          next: apps => { this.initApps(apps); this.loading = false; },
          error: () => this.loading = false
        });
      } else { this.loading = false; }
    } else {
      this.applicationService.getAllApplications().subscribe({
        next: apps => { this.initApps(apps); this.loading = false; },
        error: () => this.loading = false
      });
    }
  }

  private initApps(apps: ApplicationResponse[]): void {
    this.applications = apps;
    apps.forEach(a => this.statusUpdates[a.applicationId] = a.status);
  }

  updateStatus(id: number): void {
    this.applicationService.updateApplicationStatus(id, this.statusUpdates[id]).subscribe({
      next: updated => {
        const idx = this.applications.findIndex(a => a.applicationId === id);
        if (idx >= 0) this.applications[idx] = updated;
      },
      error: err => alert(err.error || 'Update failed')
    });
  }

  viewEligibility(applicationId: number): void {
    this.applicationService.getEligibilityChecksByApplication(applicationId).subscribe({
      next: checks => alert(
        checks.length === 0
          ? 'No eligibility checks for this application.'
          : checks.map(c => `Check #${c.checkId}: ${c.result} — ${c.notes || 'No notes'}`).join('\n')
      ),
      error: () => alert('Failed to load eligibility checks')
    });
  }

  createApp(): void { this.router.navigate(['/applications/create']); }

  getStatusBadge(status: string): string {
    const map: Record<string, string> = {
      APPROVED: 'badge-success', DISBURSED: 'badge-success',
      REJECTED: 'badge-danger', PENDING: 'badge-warning', UNDER_REVIEW: 'badge-info'
    };
    return map[status] || 'badge-neutral';
  }
}
