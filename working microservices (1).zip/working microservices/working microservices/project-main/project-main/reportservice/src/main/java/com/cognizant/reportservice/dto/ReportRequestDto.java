package com.cognizant.reportservice.dto;
import com.cognizant.reportservice.entity.Report; import lombok.*;
@Data
@NoArgsConstructor @AllArgsConstructor @Builder
public class ReportRequestDto {
    private Report.ReportScope scope;
    private String metrics;
}
