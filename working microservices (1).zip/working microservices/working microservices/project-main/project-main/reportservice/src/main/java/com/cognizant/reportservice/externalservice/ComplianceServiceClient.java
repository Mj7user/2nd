package com.cognizant.reportservice.externalservice;
import org.springframework.cloud.openfeign.FeignClient; import org.springframework.web.bind.annotation.GetMapping;
@FeignClient(name = "compliance-service")
public interface ComplianceServiceClient {
    @GetMapping("/compliance")
    Object getAllComplianceRecords();
}
