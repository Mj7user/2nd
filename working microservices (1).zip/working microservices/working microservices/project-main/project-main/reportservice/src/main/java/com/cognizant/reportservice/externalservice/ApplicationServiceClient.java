package com.cognizant.reportservice.externalservice;
import org.springframework.cloud.openfeign.FeignClient; import org.springframework.web.bind.annotation.GetMapping;
@FeignClient(name = "application-service")
public interface ApplicationServiceClient { @GetMapping("/applications") Object getAllApplications(); }
