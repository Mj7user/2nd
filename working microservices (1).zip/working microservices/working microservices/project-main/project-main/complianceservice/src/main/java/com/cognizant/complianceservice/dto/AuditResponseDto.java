package com.cognizant.complianceservice.dto;
import com.cognizant.complianceservice.entity.Audit; import lombok.*; import java.time.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditResponseDto {
    private Long auditId;
    private Long officerId;
    private String scope;
    private String findings;
    private Long userId;
    private Long citizenId;
    private String modeOfApplication;
    private LocalDate date;
    private Audit.AuditStatus status;
    private LocalDateTime createdAt;
}
