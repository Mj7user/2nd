package com.cognizant.complianceservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.time.*;
@Entity @Table(name="compliance_records") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ComplianceRecord {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long complianceId;
    @Column(nullable=false) private Long entityId;
    @Enumerated(EnumType.STRING) private EntityType type;
    @Enumerated(EnumType.STRING) @Builder.Default private ComplianceResult result = ComplianceResult.PENDING;
    @Builder.Default private LocalDate date = LocalDate.now();
    @Column(columnDefinition="TEXT") private String notes;
    @CreationTimestamp private LocalDateTime createdAt;
    public enum EntityType { APPLICATION, PROGRAM, DISBURSEMENT }
    public enum ComplianceResult { PENDING, COMPLIANT, NON_COMPLIANT }
}
