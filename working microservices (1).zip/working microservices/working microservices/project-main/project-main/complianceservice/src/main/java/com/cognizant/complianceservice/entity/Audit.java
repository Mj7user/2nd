package com.cognizant.complianceservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.time.*;
@Entity @Table(name="audits") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Audit {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long auditId;
    @Column(nullable=false) private Long officerId;
    @Column(columnDefinition="TEXT") private String scope;
    @Column(columnDefinition="TEXT") private String findings;
    private Long userId;
    private Long citizenId;
    private String modeOfApplication;
    @Builder.Default private LocalDate date = LocalDate.now();
    @Enumerated(EnumType.STRING) @Builder.Default private AuditStatus status = AuditStatus.IN_PROGRESS;
    @CreationTimestamp private LocalDateTime createdAt;
    public enum AuditStatus { IN_PROGRESS, COMPLETED, CLOSED }
}
