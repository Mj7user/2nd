package com.cognizant.complianceservice.exception;
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String m) { super(m); } }
