package com.cognizant.notificationservice.dto;
import com.cognizant.notificationservice.entity.Notification; import lombok.*; import java.time.LocalDateTime;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class NotificationResponseDto {
    private Long notificationId;
    private Long userId;
    private Long entityId;
    private String message;
    private Notification.NotificationCategory category;
    private Notification.NotificationStatus status;
    private LocalDateTime createdDate;
}
