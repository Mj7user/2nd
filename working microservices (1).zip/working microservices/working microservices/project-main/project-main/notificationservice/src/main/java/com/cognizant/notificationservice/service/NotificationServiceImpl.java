package com.cognizant.notificationservice.service;
import com.cognizant.notificationservice.dao.NotificationRepository;
import com.cognizant.notificationservice.dto.*;
import com.cognizant.notificationservice.entity.Notification;
import com.cognizant.notificationservice.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {
    private final NotificationRepository notificationRepository;

    @Override
    public NotificationResponseDto createNotification(NotificationRequestDto dto) {
        Notification n = Notification.builder()
                .userId(dto.getUserId()).entityId(dto.getEntityId()).message(dto.getMessage()).category(dto.getCategory()).build();
        return toDto(notificationRepository.save(n));
    }
    @Override
    public NotificationResponseDto getNotificationById(Long id) {
        return toDto(notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found: " + id)));
    }
    @Override
    public List<NotificationResponseDto> getNotificationsByUser(Long userId) {
        return notificationRepository.findByUserId(userId).stream().map(this::toDto).collect(Collectors.toList());
    }
    @Override
    public List<NotificationResponseDto> getUnreadByUser(Long userId) {
        return notificationRepository.findByUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD).stream().map(this::toDto).collect(Collectors.toList());
    }
    @Override
    public NotificationResponseDto markAsRead(Long id) {
        Notification n = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found: " + id));
        n.setStatus(Notification.NotificationStatus.READ);
        return toDto(notificationRepository.save(n));
    }
    private NotificationResponseDto toDto(Notification n) {
        return NotificationResponseDto.builder()
                .notificationId(n.getNotificationId())
                .userId(n.getUserId())
                .entityId(n.getEntityId())
                .message(n.getMessage())
                .category(n.getCategory())
                .status(n.getStatus())
                .createdDate(n.getCreatedDate())
                .build();
    }
}
