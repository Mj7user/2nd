package com.cognizant.applicationservice.controller;

import com.cognizant.applicationservice.dto.*;
import com.cognizant.applicationservice.service.WelfareApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/applications")
@RequiredArgsConstructor
public class WelfareApplicationController {

    private final WelfareApplicationService applicationService;

    @PostMapping
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<ApplicationResponseDto> createApplication(@RequestBody ApplicationRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(applicationService.createApplication(dto));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<ApplicationResponseDto> getApplication(@PathVariable Long id) {
        return ResponseEntity.ok(applicationService.getApplicationById(id));
    }

    @GetMapping("/citizen/{citizenId}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<List<ApplicationResponseDto>> getApplicationsByCitizen(@PathVariable Long citizenId) {
        return ResponseEntity.ok(applicationService.getApplicationsByCitizen(citizenId));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    public ResponseEntity<List<ApplicationResponseDto>> getAllApplications() {
        return ResponseEntity.ok(applicationService.getAllApplications());
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<ApplicationResponseDto> updateStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(applicationService.updateStatus(id, status));
    }
}
