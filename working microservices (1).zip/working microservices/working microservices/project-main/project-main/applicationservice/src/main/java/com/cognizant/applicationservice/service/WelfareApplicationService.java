package com.cognizant.applicationservice.service;

import com.cognizant.applicationservice.dto.*;
import java.util.List;

public interface WelfareApplicationService {
    ApplicationResponseDto createApplication(ApplicationRequestDto dto);
    ApplicationResponseDto getApplicationById(Long id);
    List<ApplicationResponseDto> getApplicationsByCitizen(Long citizenId);
    List<ApplicationResponseDto> getAllApplications();
    ApplicationResponseDto updateStatus(Long id, String status);
}
