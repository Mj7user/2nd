package com.cognizant.applicationservice.dto;

import com.cognizant.applicationservice.entity.EligibilityCheck;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class EligibilityCheckRequestDto {
    private Long applicationId;
    private Long officerId;
    private EligibilityCheck.CheckResult result;
    private String notes;
}
