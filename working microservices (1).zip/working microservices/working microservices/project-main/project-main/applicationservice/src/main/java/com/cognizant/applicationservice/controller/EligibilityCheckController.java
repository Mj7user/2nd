package com.cognizant.applicationservice.controller;

import com.cognizant.applicationservice.dto.*;
import com.cognizant.applicationservice.service.EligibilityCheckService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/eligibility-checks")
@RequiredArgsConstructor
public class EligibilityCheckController {

    private final EligibilityCheckService eligibilityCheckService;

    @PostMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<EligibilityCheckResponseDto> createCheck(@RequestBody EligibilityCheckRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(eligibilityCheckService.createCheck(dto));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<EligibilityCheckResponseDto> getCheck(@PathVariable Long id) {
        return ResponseEntity.ok(eligibilityCheckService.getCheckById(id));
    }

    @GetMapping("/application/{applicationId}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<List<EligibilityCheckResponseDto>> getChecksByApplication(@PathVariable Long applicationId) {
        return ResponseEntity.ok(eligibilityCheckService.getChecksByApplication(applicationId));
    }
}
