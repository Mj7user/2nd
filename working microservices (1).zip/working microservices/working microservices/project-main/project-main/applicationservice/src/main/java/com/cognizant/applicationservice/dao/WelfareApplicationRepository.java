package com.cognizant.applicationservice.dao;

import com.cognizant.applicationservice.entity.WelfareApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface WelfareApplicationRepository extends JpaRepository<WelfareApplication, Long> {
    List<WelfareApplication> findByCitizenId(Long citizenId);
    List<WelfareApplication> findByProgramId(Long programId);
    List<WelfareApplication> findByStatus(WelfareApplication.ApplicationStatus status);
}
