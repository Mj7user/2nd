package com.cognizant.userservice.client;

import com.cognizant.userservice.dto.CitizenResponseDto;  // ← Use local DTO
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "citizen-service", url = "http://localhost:8084")
public interface CitizenServiceClient {

    @PostMapping("/citizens/register")
    CitizenResponseDto registerCitizen(@RequestParam Long userId, @RequestParam String name, @RequestParam String email, @RequestParam String contactInfo);
}
