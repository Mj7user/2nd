package com.cognizant.disbursementservice.service;

import com.cognizant.disbursementservice.dao.DisbursementRepository;
import com.cognizant.disbursementservice.dao.PaymentRepository;
import com.cognizant.disbursementservice.dto.PaymentRequestDto;
import com.cognizant.disbursementservice.dto.PaymentResponseDto;
import com.cognizant.disbursementservice.entity.Disbursement;
import com.cognizant.disbursementservice.entity.Payment;
import com.cognizant.disbursementservice.exception.ResourceNotFoundException;
import com.cognizant.disbursementservice.externalservice.NotificationServiceClient;
import com.cognizant.notificationservice.dto.NotificationRequestDto;
import com.cognizant.notificationservice.entity.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final DisbursementRepository disbursementRepository;  // ✅ ADD THIS
    private final NotificationServiceClient notificationServiceClient;  // ✅ ADD THIS

    @Override
    public PaymentResponseDto createPayment(PaymentRequestDto dto) {
        // Get disbursement to retrieve citizenId
        Disbursement disbursement = disbursementRepository.findById(dto.getDisbursementId())
                .orElseThrow(() -> new ResourceNotFoundException("Disbursement not found: " + dto.getDisbursementId()));

        Payment p = Payment.builder()
                .disbursementId(dto.getDisbursementId())
                .method(dto.getMethod())
                .build();

        PaymentResponseDto saved = toDto(paymentRepository.save(p));

        // ✅ Send notification
        try {
            NotificationRequestDto notificationDto = NotificationRequestDto.builder()
                    .userId(disbursement.getCitizenId())  // Get from disbursement
                    .entityId(saved.getPaymentId())
                    .message("Payment of " + disbursement.getAmount() + " via " + dto.getMethod() + " has been initiated.")
                    .category(Notification.NotificationCategory.PAYMENT)  // Can use DISBURSEMENT category
                    .build();
            notificationServiceClient.createNotification(notificationDto);
            log.info("✓ Notification sent for payment: {}", saved.getPaymentId());
        } catch (Exception e) {
            log.warn("⚠️ Failed to send notification: {}", e.getMessage());
        }

        return saved;
    }

    @Override
    public PaymentResponseDto getPaymentById(Long id) {
        return toDto(paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + id)));
    }

    @Override
    public List<PaymentResponseDto> getPaymentsByDisbursement(Long disbursementId) {
        return paymentRepository.findByDisbursementId(disbursementId)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    private PaymentResponseDto toDto(Payment p) {
        return PaymentResponseDto.builder()
                .paymentId(p.getPaymentId())
                .disbursementId(p.getDisbursementId())
                .method(p.getMethod())
                .date(p.getDate())
                .status(p.getStatus())
                .build();
    }
}
