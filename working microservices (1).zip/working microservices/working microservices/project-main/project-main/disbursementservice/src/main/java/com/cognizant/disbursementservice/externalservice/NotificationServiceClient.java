package com.cognizant.disbursementservice.externalservice;

import com.cognizant.notificationservice.dto.NotificationRequestDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service")
public interface NotificationServiceClient {

    @PostMapping("/notifications/internal")
    Object createNotification(@RequestBody NotificationRequestDto dto);
}
