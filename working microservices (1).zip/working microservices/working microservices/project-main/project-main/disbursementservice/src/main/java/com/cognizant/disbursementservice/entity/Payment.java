package com.cognizant.disbursementservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.time.*;
@Entity @Table(name="payments") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Payment {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long paymentId;
    @Column(nullable=false) private Long disbursementId;
    @Enumerated(EnumType.STRING) private PaymentMethod method;
    @Builder.Default private LocalDate date = LocalDate.now();
    @Enumerated(EnumType.STRING) @Builder.Default private PaymentStatus status = PaymentStatus.PENDING;
    @CreationTimestamp private LocalDateTime createdAt;
    public enum PaymentMethod { BANK, WALLET, CASH }
    public enum PaymentStatus { PENDING, SUCCESS, FAILED }
}
