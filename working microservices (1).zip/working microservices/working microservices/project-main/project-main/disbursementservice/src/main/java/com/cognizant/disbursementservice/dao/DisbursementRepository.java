package com.cognizant.disbursementservice.dao;
import com.cognizant.disbursementservice.entity.Disbursement; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {
    List<Disbursement> findByApplicationId(Long applicationId);
    List<Disbursement> findByStatus(Disbursement.DisbursementStatus status);
}
