package com.cognizant.citizenservice.dto;

import com.cognizant.citizenservice.entity.CitizenDocument;
import lombok.*;

import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class DocumentResponseDto {
    private Long documentId;
    private Long citizenId;
    private CitizenDocument.DocType docType;
    private String fileUri;
    private LocalDate uploadedDate;
    private CitizenDocument.VerificationStatus verificationStatus;
}
