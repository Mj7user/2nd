package com.cognizant.citizenservice.dto;

import com.cognizant.citizenservice.entity.Citizen;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class CitizenRequestDto {
    @NotBlank
    private String name;
    private LocalDate dob;
    private Citizen.Gender gender;
    private String address;
    private String contactInfo;
    private Long userId;  // This will be set automatically from user registration
}
