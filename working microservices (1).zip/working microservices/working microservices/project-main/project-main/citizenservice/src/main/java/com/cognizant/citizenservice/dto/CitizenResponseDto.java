package com.cognizant.citizenservice.dto;

import com.cognizant.citizenservice.entity.Citizen;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class CitizenResponseDto {
    private Long citizenId;
    private String name;
    private String email;
    private LocalDate dob;
    private Citizen.Gender gender;
    private String address;
    private String contactInfo;
    private Citizen.CitizenStatus status;
    private Long userId;
    private LocalDateTime createdAt;
}
