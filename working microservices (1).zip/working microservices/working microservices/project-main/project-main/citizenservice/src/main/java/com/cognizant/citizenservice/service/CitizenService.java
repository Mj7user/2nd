package com.cognizant.citizenservice.service;

import com.cognizant.citizenservice.dto.*;
import java.util.List;

public interface CitizenService {
    CitizenResponseDto createCitizen(CitizenRequestDto dto);
    CitizenResponseDto getCitizenById(Long id);
    CitizenResponseDto getCitizenByUserId(Long userId);
    List<CitizenResponseDto> getAllCitizens();
    CitizenResponseDto updateCitizen(Long id, CitizenRequestDto dto);
    // Add this to CitizenService interface
    CitizenResponseDto registerCitizen(Long userId, String name, String email, String contactInfo);

    void deleteCitizen(Long id);
}
