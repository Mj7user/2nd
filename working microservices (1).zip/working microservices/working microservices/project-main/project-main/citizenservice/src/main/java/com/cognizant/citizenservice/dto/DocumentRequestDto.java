package com.cognizant.citizenservice.dto;

import com.cognizant.citizenservice.entity.CitizenDocument;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class DocumentRequestDto {
    private Long citizenId;
    @NotBlank
    private CitizenDocument.DocType docType;
    @NotBlank
    private String fileUri;
}
